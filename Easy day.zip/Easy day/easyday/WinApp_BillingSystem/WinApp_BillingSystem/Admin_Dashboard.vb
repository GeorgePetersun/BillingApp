﻿Public Class Admin_Dashboard


    Private Sub CategoryToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CategoryToolStripMenuItem.Click
        Dim cat As New category
        cat.MdiParent = Me
        cat.Show()
    End Sub

    Private Sub ProductsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProductsToolStripMenuItem.Click
        Dim pro As New Products
        pro.MdiParent = Me
        pro.Show()
    End Sub



    Private Sub CustomerInformationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CustomerInformationToolStripMenuItem.Click
        Dim cus As New CustomerInfo
        cus.MdiParent = Me
        cus.Show()
    End Sub

    Private Sub BillingSectionToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BillingSectionToolStripMenuItem.Click
        BilligSection.Show()
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub SalesReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalesReportToolStripMenuItem.Click
        Dim sal As New SalesReport
        sal.MdiParent = Me
        sal.Show()
    End Sub
End Class