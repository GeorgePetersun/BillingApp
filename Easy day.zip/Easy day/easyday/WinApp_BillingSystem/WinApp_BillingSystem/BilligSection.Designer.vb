﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class BilligSection
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Customerdetails = New System.Windows.Forms.GroupBox()
        Me.CusID_txt = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Savecus_btn = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.adres_txt = New System.Windows.Forms.TextBox()
        Me.contact_txt = New System.Windows.Forms.TextBox()
        Me.email_txt = New System.Windows.Forms.TextBox()
        Me.search_btn = New System.Windows.Forms.Button()
        Me.Name_txt = New System.Windows.Forms.TextBox()
        Me.search_text = New System.Windows.Forms.TextBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Name_lbl = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.prosearch_txt = New System.Windows.Forms.ComboBox()
        Me.ProID_txt = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Add_btn = New System.Windows.Forms.Button()
        Me.Quantity_txt = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.rate_txt = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.nametxt = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Admin_Footer = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.ProductGridview = New System.Windows.Forms.DataGridView()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Subtotal_txt = New System.Windows.Forms.TextBox()
        Me.Discount_txt = New System.Windows.Forms.TextBox()
        Me.vat_txt = New System.Windows.Forms.TextBox()
        Me.Grandtotal_txt = New System.Windows.Forms.TextBox()
        Me.Save_btn = New System.Windows.Forms.Button()
        Me.Print_btn = New System.Windows.Forms.Button()
        Me.paid_txt = New System.Windows.Forms.TextBox()
        Me.return_txt = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Customerdetails.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Admin_Footer.SuspendLayout()
        CType(Me.ProductGridview, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Customerdetails
        '
        Me.Customerdetails.Controls.Add(Me.CusID_txt)
        Me.Customerdetails.Controls.Add(Me.Label9)
        Me.Customerdetails.Controls.Add(Me.Savecus_btn)
        Me.Customerdetails.Controls.Add(Me.Label4)
        Me.Customerdetails.Controls.Add(Me.adres_txt)
        Me.Customerdetails.Controls.Add(Me.contact_txt)
        Me.Customerdetails.Controls.Add(Me.email_txt)
        Me.Customerdetails.Controls.Add(Me.search_btn)
        Me.Customerdetails.Controls.Add(Me.Name_txt)
        Me.Customerdetails.Controls.Add(Me.search_text)
        Me.Customerdetails.Controls.Add(Me.DateTimePicker1)
        Me.Customerdetails.Controls.Add(Me.Label3)
        Me.Customerdetails.Controls.Add(Me.Label2)
        Me.Customerdetails.Controls.Add(Me.Label1)
        Me.Customerdetails.Controls.Add(Me.Name_lbl)
        Me.Customerdetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Customerdetails.Location = New System.Drawing.Point(12, 12)
        Me.Customerdetails.Name = "Customerdetails"
        Me.Customerdetails.Size = New System.Drawing.Size(1346, 123)
        Me.Customerdetails.TabIndex = 0
        Me.Customerdetails.TabStop = False
        Me.Customerdetails.Text = "Customer Details"
        '
        'CusID_txt
        '
        Me.CusID_txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CusID_txt.Location = New System.Drawing.Point(299, 18)
        Me.CusID_txt.Name = "CusID_txt"
        Me.CusID_txt.ReadOnly = True
        Me.CusID_txt.Size = New System.Drawing.Size(176, 23)
        Me.CusID_txt.TabIndex = 52
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(232, 25)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(21, 17)
        Me.Label9.TabIndex = 51
        Me.Label9.Text = "ID"
        '
        'Savecus_btn
        '
        Me.Savecus_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Savecus_btn.Location = New System.Drawing.Point(1122, 75)
        Me.Savecus_btn.Name = "Savecus_btn"
        Me.Savecus_btn.Size = New System.Drawing.Size(200, 23)
        Me.Savecus_btn.TabIndex = 50
        Me.Savecus_btn.Text = "Save Customer Details"
        Me.Savecus_btn.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(1056, 25)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 17)
        Me.Label4.TabIndex = 49
        Me.Label4.Text = "Bill Date"
        '
        'adres_txt
        '
        Me.adres_txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.adres_txt.Location = New System.Drawing.Point(847, 25)
        Me.adres_txt.Multiline = True
        Me.adres_txt.Name = "adres_txt"
        Me.adres_txt.Size = New System.Drawing.Size(176, 79)
        Me.adres_txt.TabIndex = 48
        '
        'contact_txt
        '
        Me.contact_txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.contact_txt.Location = New System.Drawing.Point(562, 69)
        Me.contact_txt.Name = "contact_txt"
        Me.contact_txt.Size = New System.Drawing.Size(176, 23)
        Me.contact_txt.TabIndex = 47
        '
        'email_txt
        '
        Me.email_txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.email_txt.Location = New System.Drawing.Point(562, 22)
        Me.email_txt.Name = "email_txt"
        Me.email_txt.Size = New System.Drawing.Size(176, 23)
        Me.email_txt.TabIndex = 46
        '
        'search_btn
        '
        Me.search_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.search_btn.Location = New System.Drawing.Point(43, 69)
        Me.search_btn.Name = "search_btn"
        Me.search_btn.Size = New System.Drawing.Size(75, 23)
        Me.search_btn.TabIndex = 45
        Me.search_btn.Text = "Search"
        Me.search_btn.UseVisualStyleBackColor = True
        '
        'Name_txt
        '
        Me.Name_txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name_txt.Location = New System.Drawing.Point(299, 69)
        Me.Name_txt.Name = "Name_txt"
        Me.Name_txt.Size = New System.Drawing.Size(176, 23)
        Me.Name_txt.TabIndex = 44
        '
        'search_text
        '
        Me.search_text.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.search_text.Location = New System.Drawing.Point(27, 40)
        Me.search_text.Name = "search_text"
        Me.search_text.Size = New System.Drawing.Size(116, 23)
        Me.search_text.TabIndex = 43
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker1.Location = New System.Drawing.Point(1122, 24)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 42
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(774, 24)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 17)
        Me.Label3.TabIndex = 41
        Me.Label3.Text = "Address"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(481, 69)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 17)
        Me.Label2.TabIndex = 40
        Me.Label2.Text = "Contact"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(481, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 17)
        Me.Label1.TabIndex = 39
        Me.Label1.Text = "Email"
        '
        'Name_lbl
        '
        Me.Name_lbl.AutoSize = True
        Me.Name_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name_lbl.Location = New System.Drawing.Point(232, 75)
        Me.Name_lbl.Name = "Name_lbl"
        Me.Name_lbl.Size = New System.Drawing.Size(45, 17)
        Me.Name_lbl.TabIndex = 38
        Me.Name_lbl.Text = "Name"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.prosearch_txt)
        Me.GroupBox1.Controls.Add(Me.ProID_txt)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Add_btn)
        Me.GroupBox1.Controls.Add(Me.Quantity_txt)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.rate_txt)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.nametxt)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 141)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1346, 107)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Product Details"
        '
        'prosearch_txt
        '
        Me.prosearch_txt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.prosearch_txt.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.prosearch_txt.FormattingEnabled = True
        Me.prosearch_txt.Location = New System.Drawing.Point(22, 40)
        Me.prosearch_txt.Name = "prosearch_txt"
        Me.prosearch_txt.Size = New System.Drawing.Size(121, 24)
        Me.prosearch_txt.TabIndex = 57
        '
        'ProID_txt
        '
        Me.ProID_txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProID_txt.Location = New System.Drawing.Point(299, 38)
        Me.ProID_txt.Name = "ProID_txt"
        Me.ProID_txt.ReadOnly = True
        Me.ProID_txt.Size = New System.Drawing.Size(176, 23)
        Me.ProID_txt.TabIndex = 56
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(222, 44)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(71, 17)
        Me.Label10.TabIndex = 55
        Me.Label10.Text = "Item Code"
        '
        'Add_btn
        '
        Me.Add_btn.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Add_btn.Location = New System.Drawing.Point(1174, 67)
        Me.Add_btn.Name = "Add_btn"
        Me.Add_btn.Size = New System.Drawing.Size(75, 23)
        Me.Add_btn.TabIndex = 54
        Me.Add_btn.Text = "Add"
        Me.Add_btn.UseVisualStyleBackColor = True
        '
        'Quantity_txt
        '
        Me.Quantity_txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Quantity_txt.Location = New System.Drawing.Point(1123, 34)
        Me.Quantity_txt.Name = "Quantity_txt"
        Me.Quantity_txt.Size = New System.Drawing.Size(176, 23)
        Me.Quantity_txt.TabIndex = 53
        Me.Quantity_txt.Text = "1"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(1056, 40)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(61, 17)
        Me.Label7.TabIndex = 52
        Me.Label7.Text = "Quantity"
        '
        'rate_txt
        '
        Me.rate_txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rate_txt.Location = New System.Drawing.Point(847, 38)
        Me.rate_txt.Name = "rate_txt"
        Me.rate_txt.ReadOnly = True
        Me.rate_txt.Size = New System.Drawing.Size(176, 23)
        Me.rate_txt.TabIndex = 51
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(774, 44)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(38, 17)
        Me.Label6.TabIndex = 50
        Me.Label6.Text = "Rate"
        '
        'nametxt
        '
        Me.nametxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nametxt.Location = New System.Drawing.Point(559, 38)
        Me.nametxt.Name = "nametxt"
        Me.nametxt.ReadOnly = True
        Me.nametxt.Size = New System.Drawing.Size(176, 23)
        Me.nametxt.TabIndex = 49
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(481, 44)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(45, 17)
        Me.Label5.TabIndex = 48
        Me.Label5.Text = "Name"
        '
        'Admin_Footer
        '
        Me.Admin_Footer.BackColor = System.Drawing.SystemColors.Highlight
        Me.Admin_Footer.Controls.Add(Me.Label8)
        Me.Admin_Footer.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Admin_Footer.Location = New System.Drawing.Point(0, 649)
        Me.Admin_Footer.Name = "Admin_Footer"
        Me.Admin_Footer.Size = New System.Drawing.Size(1370, 47)
        Me.Admin_Footer.TabIndex = 2
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label8.Location = New System.Drawing.Point(568, 20)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(224, 18)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Developed By Loyola Web Team"
        '
        'ProductGridview
        '
        Me.ProductGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ProductGridview.Location = New System.Drawing.Point(12, 254)
        Me.ProductGridview.Name = "ProductGridview"
        Me.ProductGridview.Size = New System.Drawing.Size(554, 370)
        Me.ProductGridview.TabIndex = 55
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(608, 291)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(69, 17)
        Me.Label11.TabIndex = 56
        Me.Label11.Text = "Sub Total"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(608, 335)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(85, 17)
        Me.Label12.TabIndex = 57
        Me.Label12.Text = "Discount(%)"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(608, 382)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(59, 17)
        Me.Label13.TabIndex = 58
        Me.Label13.Text = "GST(%)"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(608, 425)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(84, 17)
        Me.Label14.TabIndex = 59
        Me.Label14.Text = "Grand Total"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(608, 470)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(88, 17)
        Me.Label15.TabIndex = 60
        Me.Label15.Text = "Paid Amount"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(608, 515)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(103, 17)
        Me.Label16.TabIndex = 61
        Me.Label16.Text = "Return Amount"
        '
        'Subtotal_txt
        '
        Me.Subtotal_txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Subtotal_txt.Location = New System.Drawing.Point(719, 285)
        Me.Subtotal_txt.Name = "Subtotal_txt"
        Me.Subtotal_txt.ReadOnly = True
        Me.Subtotal_txt.Size = New System.Drawing.Size(176, 23)
        Me.Subtotal_txt.TabIndex = 62
        Me.Subtotal_txt.Text = "0"
        '
        'Discount_txt
        '
        Me.Discount_txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Discount_txt.Location = New System.Drawing.Point(719, 329)
        Me.Discount_txt.Name = "Discount_txt"
        Me.Discount_txt.ReadOnly = True
        Me.Discount_txt.Size = New System.Drawing.Size(176, 23)
        Me.Discount_txt.TabIndex = 63
        Me.Discount_txt.Text = "0"
        '
        'vat_txt
        '
        Me.vat_txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.vat_txt.Location = New System.Drawing.Point(719, 376)
        Me.vat_txt.Name = "vat_txt"
        Me.vat_txt.ReadOnly = True
        Me.vat_txt.Size = New System.Drawing.Size(176, 23)
        Me.vat_txt.TabIndex = 64
        Me.vat_txt.Text = "0"
        '
        'Grandtotal_txt
        '
        Me.Grandtotal_txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Grandtotal_txt.Location = New System.Drawing.Point(719, 425)
        Me.Grandtotal_txt.Name = "Grandtotal_txt"
        Me.Grandtotal_txt.ReadOnly = True
        Me.Grandtotal_txt.Size = New System.Drawing.Size(176, 23)
        Me.Grandtotal_txt.TabIndex = 65
        Me.Grandtotal_txt.Text = "0"
        '
        'Save_btn
        '
        Me.Save_btn.Location = New System.Drawing.Point(749, 555)
        Me.Save_btn.Name = "Save_btn"
        Me.Save_btn.Size = New System.Drawing.Size(75, 23)
        Me.Save_btn.TabIndex = 68
        Me.Save_btn.Text = "Save"
        Me.Save_btn.UseVisualStyleBackColor = True
        '
        'Print_btn
        '
        Me.Print_btn.Location = New System.Drawing.Point(1124, 555)
        Me.Print_btn.Name = "Print_btn"
        Me.Print_btn.Size = New System.Drawing.Size(75, 23)
        Me.Print_btn.TabIndex = 69
        Me.Print_btn.Text = "Print"
        Me.Print_btn.UseVisualStyleBackColor = True
        '
        'paid_txt
        '
        Me.paid_txt.Location = New System.Drawing.Point(719, 467)
        Me.paid_txt.Name = "paid_txt"
        Me.paid_txt.Size = New System.Drawing.Size(176, 20)
        Me.paid_txt.TabIndex = 0
        '
        'return_txt
        '
        Me.return_txt.Location = New System.Drawing.Point(719, 515)
        Me.return_txt.Name = "return_txt"
        Me.return_txt.Size = New System.Drawing.Size(176, 20)
        Me.return_txt.TabIndex = 71
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.WinApp_BillingSystem.My.Resources.Resources.Untitled
        Me.PictureBox1.Location = New System.Drawing.Point(921, 285)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(437, 250)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 53
        Me.PictureBox1.TabStop = False
        '
        'BilligSection
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 696)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.return_txt)
        Me.Controls.Add(Me.paid_txt)
        Me.Controls.Add(Me.Print_btn)
        Me.Controls.Add(Me.Save_btn)
        Me.Controls.Add(Me.Grandtotal_txt)
        Me.Controls.Add(Me.vat_txt)
        Me.Controls.Add(Me.Discount_txt)
        Me.Controls.Add(Me.Subtotal_txt)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.ProductGridview)
        Me.Controls.Add(Me.Admin_Footer)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Customerdetails)
        Me.Name = "BilligSection"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Easy Day Billing System | Billing Section"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Customerdetails.ResumeLayout(False)
        Me.Customerdetails.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Admin_Footer.ResumeLayout(False)
        Me.Admin_Footer.PerformLayout()
        CType(Me.ProductGridview, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Customerdetails As GroupBox
    Friend WithEvents adres_txt As TextBox
    Friend WithEvents contact_txt As TextBox
    Friend WithEvents email_txt As TextBox
    Friend WithEvents search_btn As Button
    Friend WithEvents Name_txt As TextBox
    Friend WithEvents search_text As TextBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Name_lbl As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label4 As Label
    Friend WithEvents nametxt As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents rate_txt As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Quantity_txt As TextBox
    Friend WithEvents Add_btn As Button
    Friend WithEvents Admin_Footer As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents Savecus_btn As Button
    Friend WithEvents ProductGridview As DataGridView
    Friend WithEvents CusID_txt As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents ProID_txt As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Subtotal_txt As TextBox
    Friend WithEvents Discount_txt As TextBox
    Friend WithEvents vat_txt As TextBox
    Friend WithEvents Grandtotal_txt As TextBox
    Friend WithEvents Save_btn As Button
    Friend WithEvents Print_btn As Button
    Friend WithEvents prosearch_txt As ComboBox
    Friend WithEvents paid_txt As TextBox
    Friend WithEvents return_txt As TextBox
    Friend WithEvents PictureBox1 As PictureBox
End Class
