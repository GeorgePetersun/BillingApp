﻿Imports System.Data
Imports System.Data.OleDb

Public Class BilligSection


    Dim table As New DataTable("Table")


    Private Sub search_btn_Click(sender As Object, e As EventArgs) Handles search_btn.Click
        If search_text.Text = "" Then
            MsgBox("Please Enter the Customer Contact Number ")
            search_text.Focus()
        Else
            Dim con As New OleDbConnection
            Dim updata As New OleDbCommand
            Dim adp As New OleDbDataAdapter
            Dim dset As New DataSet
            con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
            con.Open()
            updata.Connection = con
            updata.CommandText = "Select ID,name,email,contact,address from customer where contact='" & search_text.Text & "'"
            updata.ExecuteNonQuery()
            adp.SelectCommand = updata
            adp.Fill(dset, "customer")
            If (dset.Tables("customer").Rows.Count) = 0 Then
                Name_txt.Text = ""
                email_txt.Text = ""
                contact_txt.Text = ""
                adres_txt.Text = ""
                MsgBox("Customer Not Found")
            Else
                CusID_txt.Text = dset.Tables("customer").Rows(0).Item("ID")
                Name_txt.Text = dset.Tables("customer").Rows(0).Item("name")
                email_txt.Text = dset.Tables("customer").Rows(0).Item("email")
                contact_txt.Text = dset.Tables("customer").Rows(0).Item("contact")
                adres_txt.Text = dset.Tables("customer").Rows(0).Item("address")

            End If
        End If
    End Sub

    Private Sub Savecus_btn_Click(sender As Object, e As EventArgs) Handles Savecus_btn.Click

        If Name_txt.Text = "" Then
            MsgBox("please Enter the Customer name")
            Name_txt.Focus()
        ElseIf email_txt.Text = "" Then
            MsgBox("Please Enter the Email")
            email_txt.Focus()
        ElseIf contact_txt.Text = "" Then
            MsgBox("please Enter the Contact Number")
            contact_txt.Focus()
        ElseIf adres_txt.Text = "" Then
            MsgBox("Please Enter the Address of the Customer")
            adres_txt.Focus()
        Else
            Dim con As New OleDbConnection
            Dim updata As New OleDbCommand
            Dim name As String = Name_txt.Text
            Dim email As String = email_txt.Text
            Dim contact As Double = Double.Parse(contact_txt.Text)
            Dim address As String = adres_txt.Text
            con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
            con.Open()
            updata.Connection = con
            updata.CommandText = "Insert into customer" & "(name,email,contact,address,added_date)" & "values('" & name & "','" & email & "','" & contact & "','" & address & "','" & DateTimePicker1.Value.Date & "')"
            updata.ExecuteNonQuery()
            MsgBox("Successfully Added")
        End If

    End Sub

    Private Sub Add_btn_Click(sender As Object, e As EventArgs) Handles Add_btn.Click

        If Quantity_txt.Text = "" Then
            MsgBox("You First enter the Quantity of the Product")
            Quantity_txt.Focus()
        ElseIf CusID_txt.Text = "" Then
            MsgBox("Fill all the fields to add the products")
            CusID_txt.Focus()
        ElseIf nametxt.Text = "" Then
            MsgBox("Fill all the fields to add the products")
            Name_txt.Focus()
        ElseIf email_txt.Text = "" Then
            MsgBox("Fill all the fields to add the products")
            email_txt.Focus()
        ElseIf contact_txt.Text = "" Then
            MsgBox("Fill all the fields to add the products")
            contact_txt.Focus()
        ElseIf adres_txt.Text = "" Then
            MsgBox("Fill all the fields to add the products")
            adres_txt.Focus()
        ElseIf prosearch_txt.Text = "" Then
            MsgBox("Fill all the fields to add the products")
            prosearch_txt.Focus()
        Else

            Dim amount, rate, quantity As Double
            rate = CDec(rate_txt.Text)
            quantity = CDec(Quantity_txt.Text)
            amount = rate * quantity
            Subtotal_txt.Text = Subtotal_txt.Text + amount
            table.Rows.Add(ProID_txt.Text, nametxt.Text, rate_txt.Text, Quantity_txt.Text, amount)
            ProductGridview.DataSource = table
            ProID_txt.Text = ""
            nametxt.Text = ""
            rate_txt.Text = ""
            prosearch_txt.Text = ""
        End If
        Discount_txt.Text = 5
        vat_txt.Text = 2
        Dim stotal As Decimal
        stotal = Subtotal_txt.Text / 100 * Discount_txt.Text
        Grandtotal_txt.Text = Subtotal_txt.Text - stotal
        Dim com As Decimal
        com = Subtotal_txt.Text / 100 * vat_txt.Text
        Grandtotal_txt.Text = com + Grandtotal_txt.Text
    End Sub

    Private Sub ProductSearch_btn_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub BilligSection_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim subtotal, discount, gtotal As Decimal
        subtotal = CDec(Subtotal_txt.Text)
        discount = CDec(Discount_txt.Text)
        gtotal = subtotal / 100 * discount
        Grandtotal_txt.Text = gtotal

        table.Columns.Add("Item Code", Type.GetType("System.Int32"))
        table.Columns.Add("Product Name", Type.GetType("System.String"))
        table.Columns.Add("Rate", Type.GetType("System.Int32"))
        table.Columns.Add("Quantity", Type.GetType("System.Int32"))
        table.Columns.Add("Amount", Type.GetType("System.Int32"))
        ProductGridview.DataSource = table

        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
        con.Open()
        cmd.Connection = con
        cmd.CommandText = "select name from products"
        Dim dr As OleDbDataReader = cmd.ExecuteReader
        While dr.Read
            prosearch_txt.Items.Add(dr.Item(0))
        End While
    End Sub






    Private Sub prosearch_txt_SelectedIndexChanged(sender As Object, e As EventArgs) Handles prosearch_txt.SelectedIndexChanged
        If prosearch_txt.Text = "" Then
            MsgBox("Please Enter the Productname")
            prosearch_txt.Focus()
        Else
            Dim con As New OleDbConnection
            Dim updata As New OleDbCommand
            Dim adp As New OleDbDataAdapter
            Dim dset As New DataSet
            con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
            con.Open()
            updata.Connection = con
            updata.CommandText = "Select ID,name,rate from products where name='" & prosearch_txt.Text & "'"
            updata.ExecuteNonQuery()
            adp.SelectCommand = updata
            adp.Fill(dset, "products")
            If (dset.Tables("products").Rows.Count) = 0 Then
                nametxt.Text = ""
                rate_txt.Text = ""
                MsgBox("Product Not Found")
            Else
                ProID_txt.Text = dset.Tables("products").Rows(0).Item("ID")
                nametxt.Text = dset.Tables("products").Rows(0).Item("name")
                rate_txt.Text = dset.Tables("products").Rows(0).Item("rate")
            End If
        End If
    End Sub

    Private Sub Save_btn_Click(sender As Object, e As EventArgs) Handles Save_btn.Click
        If paid_txt.Text = "" Then
            MsgBox("Please Fill all the Fields to Save")
            paid_txt.Focus()
        ElseIf return_txt.Text = "" Then
            MsgBox("Please Fill all the Fields to Save")
            return_txt.Focus()
        Else
            Dim con As New OleDbConnection
            Dim updata As New OleDbCommand
            con = New OleDbConnection("PROVIDER=" & "Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
            con.Open()
            updata.Connection = con
            updata.CommandText = "Insert into salesreport(cusid,billdate,cusname,cusnum,totalamt,paidamt,returnamt)values('" & CusID_txt.Text & "','" & DateTimePicker1.Value.Date & "','" & Name_txt.Text & "','" & contact_txt.Text & "','" & Grandtotal_txt.Text & "','" & paid_txt.Text & "','" & return_txt.Text & "')"
            updata.ExecuteNonQuery()
            MsgBox("Succesfully Saved")
        End If
    End Sub

    Private Sub paid_txt_TextChanged(sender As Object, e As EventArgs) Handles paid_txt.TextChanged
        Dim paid, ret, grand As Decimal
        paid = CDec(paid_txt.Text)
        grand = CDec(Grandtotal_txt.Text)
        ret = paid - grand
        return_txt.Text = ret

    End Sub

    Private Sub contact_txt_TextChanged(sender As Object, e As EventArgs) Handles contact_txt.TextChanged
        Dim num, num2 As Double
        num = CDbl(contact_txt.Text)
        num2 = num
        search_text.Text = num2
    End Sub

    Private Sub Print_btn_Click(sender As Object, e As EventArgs) Handles Print_btn.Click
        Print.Show()
    End Sub
End Class