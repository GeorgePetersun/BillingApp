﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CustomerInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Search_txt = New System.Windows.Forms.TextBox()
        Me.address_txtbx = New System.Windows.Forms.TextBox()
        Me.address_lbl = New System.Windows.Forms.Label()
        Me.contact_txtbx = New System.Windows.Forms.TextBox()
        Me.contact_lbl = New System.Windows.Forms.Label()
        Me.email_txtbx = New System.Windows.Forms.TextBox()
        Me.email_lbl = New System.Windows.Forms.Label()
        Me.Name_txtbx = New System.Windows.Forms.TextBox()
        Me.Name_lbl = New System.Windows.Forms.Label()
        Me.ID_txtbx = New System.Windows.Forms.TextBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.ID_lbl = New System.Windows.Forms.Label()
        Me.sea_btn = New System.Windows.Forms.Button()
        Me.CustomerDataGridView = New System.Windows.Forms.DataGridView()
        Me.Add_btn = New System.Windows.Forms.Button()
        Me.Update_btn = New System.Windows.Forms.Button()
        Me.Delete_btn = New System.Windows.Forms.Button()
        Me.Refresh_btn = New System.Windows.Forms.Button()
        Me.Clear_btn = New System.Windows.Forms.Button()
        Me.Filter_ComboBox = New System.Windows.Forms.ComboBox()
        Me.Admin_Footer = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        CType(Me.CustomerDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Admin_Footer.SuspendLayout()
        Me.SuspendLayout()
        '
        'Search_txt
        '
        Me.Search_txt.Location = New System.Drawing.Point(686, 158)
        Me.Search_txt.Name = "Search_txt"
        Me.Search_txt.Size = New System.Drawing.Size(201, 20)
        Me.Search_txt.TabIndex = 45
        '
        'address_txtbx
        '
        Me.address_txtbx.Location = New System.Drawing.Point(262, 354)
        Me.address_txtbx.Multiline = True
        Me.address_txtbx.Name = "address_txtbx"
        Me.address_txtbx.Size = New System.Drawing.Size(237, 105)
        Me.address_txtbx.TabIndex = 44
        '
        'address_lbl
        '
        Me.address_lbl.AutoSize = True
        Me.address_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.address_lbl.Location = New System.Drawing.Point(171, 354)
        Me.address_lbl.Name = "address_lbl"
        Me.address_lbl.Size = New System.Drawing.Size(60, 17)
        Me.address_lbl.TabIndex = 43
        Me.address_lbl.Text = "Address"
        '
        'contact_txtbx
        '
        Me.contact_txtbx.Location = New System.Drawing.Point(262, 301)
        Me.contact_txtbx.Multiline = True
        Me.contact_txtbx.Name = "contact_txtbx"
        Me.contact_txtbx.Size = New System.Drawing.Size(237, 20)
        Me.contact_txtbx.TabIndex = 42
        '
        'contact_lbl
        '
        Me.contact_lbl.AutoSize = True
        Me.contact_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.contact_lbl.Location = New System.Drawing.Point(171, 301)
        Me.contact_lbl.Name = "contact_lbl"
        Me.contact_lbl.Size = New System.Drawing.Size(56, 17)
        Me.contact_lbl.TabIndex = 41
        Me.contact_lbl.Text = "Contact"
        '
        'email_txtbx
        '
        Me.email_txtbx.Location = New System.Drawing.Point(262, 249)
        Me.email_txtbx.Name = "email_txtbx"
        Me.email_txtbx.Size = New System.Drawing.Size(237, 20)
        Me.email_txtbx.TabIndex = 40
        '
        'email_lbl
        '
        Me.email_lbl.AutoSize = True
        Me.email_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.email_lbl.Location = New System.Drawing.Point(171, 249)
        Me.email_lbl.Name = "email_lbl"
        Me.email_lbl.Size = New System.Drawing.Size(47, 17)
        Me.email_lbl.TabIndex = 39
        Me.email_lbl.Text = "E-Mail"
        '
        'Name_txtbx
        '
        Me.Name_txtbx.Location = New System.Drawing.Point(262, 205)
        Me.Name_txtbx.Name = "Name_txtbx"
        Me.Name_txtbx.Size = New System.Drawing.Size(237, 20)
        Me.Name_txtbx.TabIndex = 38
        '
        'Name_lbl
        '
        Me.Name_lbl.AutoSize = True
        Me.Name_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name_lbl.Location = New System.Drawing.Point(171, 205)
        Me.Name_lbl.Name = "Name_lbl"
        Me.Name_lbl.Size = New System.Drawing.Size(45, 17)
        Me.Name_lbl.TabIndex = 37
        Me.Name_lbl.Text = "Name"
        '
        'ID_txtbx
        '
        Me.ID_txtbx.Location = New System.Drawing.Point(262, 159)
        Me.ID_txtbx.Name = "ID_txtbx"
        Me.ID_txtbx.ReadOnly = True
        Me.ID_txtbx.Size = New System.Drawing.Size(237, 20)
        Me.ID_txtbx.TabIndex = 36
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(262, 117)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(237, 20)
        Me.DateTimePicker1.TabIndex = 35
        Me.DateTimePicker1.Visible = False
        '
        'ID_lbl
        '
        Me.ID_lbl.AutoSize = True
        Me.ID_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ID_lbl.Location = New System.Drawing.Point(171, 162)
        Me.ID_lbl.Name = "ID_lbl"
        Me.ID_lbl.Size = New System.Drawing.Size(21, 17)
        Me.ID_lbl.TabIndex = 34
        Me.ID_lbl.Text = "ID"
        '
        'sea_btn
        '
        Me.sea_btn.Location = New System.Drawing.Point(893, 155)
        Me.sea_btn.Name = "sea_btn"
        Me.sea_btn.Size = New System.Drawing.Size(75, 23)
        Me.sea_btn.TabIndex = 46
        Me.sea_btn.Text = "Search"
        Me.sea_btn.UseVisualStyleBackColor = True
        '
        'CustomerDataGridView
        '
        Me.CustomerDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.CustomerDataGridView.Location = New System.Drawing.Point(559, 205)
        Me.CustomerDataGridView.Name = "CustomerDataGridView"
        Me.CustomerDataGridView.Size = New System.Drawing.Size(637, 328)
        Me.CustomerDataGridView.TabIndex = 47
        '
        'Add_btn
        '
        Me.Add_btn.Location = New System.Drawing.Point(262, 481)
        Me.Add_btn.Name = "Add_btn"
        Me.Add_btn.Size = New System.Drawing.Size(75, 23)
        Me.Add_btn.TabIndex = 48
        Me.Add_btn.Text = "Add"
        Me.Add_btn.UseVisualStyleBackColor = True
        '
        'Update_btn
        '
        Me.Update_btn.Location = New System.Drawing.Point(343, 481)
        Me.Update_btn.Name = "Update_btn"
        Me.Update_btn.Size = New System.Drawing.Size(75, 23)
        Me.Update_btn.TabIndex = 49
        Me.Update_btn.Text = "Edit"
        Me.Update_btn.UseVisualStyleBackColor = True
        '
        'Delete_btn
        '
        Me.Delete_btn.Location = New System.Drawing.Point(424, 481)
        Me.Delete_btn.Name = "Delete_btn"
        Me.Delete_btn.Size = New System.Drawing.Size(75, 23)
        Me.Delete_btn.TabIndex = 50
        Me.Delete_btn.Text = "Delete"
        Me.Delete_btn.UseVisualStyleBackColor = True
        '
        'Refresh_btn
        '
        Me.Refresh_btn.Location = New System.Drawing.Point(305, 510)
        Me.Refresh_btn.Name = "Refresh_btn"
        Me.Refresh_btn.Size = New System.Drawing.Size(75, 23)
        Me.Refresh_btn.TabIndex = 51
        Me.Refresh_btn.Text = "Refresh"
        Me.Refresh_btn.UseVisualStyleBackColor = True
        '
        'Clear_btn
        '
        Me.Clear_btn.Location = New System.Drawing.Point(386, 510)
        Me.Clear_btn.Name = "Clear_btn"
        Me.Clear_btn.Size = New System.Drawing.Size(75, 23)
        Me.Clear_btn.TabIndex = 52
        Me.Clear_btn.Text = "Clear"
        Me.Clear_btn.UseVisualStyleBackColor = True
        '
        'Filter_ComboBox
        '
        Me.Filter_ComboBox.FormattingEnabled = True
        Me.Filter_ComboBox.Items.AddRange(New Object() {"name", "email", "contact", "address"})
        Me.Filter_ComboBox.Location = New System.Drawing.Point(559, 158)
        Me.Filter_ComboBox.Name = "Filter_ComboBox"
        Me.Filter_ComboBox.Size = New System.Drawing.Size(121, 21)
        Me.Filter_ComboBox.TabIndex = 53
        '
        'Admin_Footer
        '
        Me.Admin_Footer.BackColor = System.Drawing.SystemColors.Highlight
        Me.Admin_Footer.Controls.Add(Me.Label5)
        Me.Admin_Footer.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Admin_Footer.Location = New System.Drawing.Point(0, 649)
        Me.Admin_Footer.Name = "Admin_Footer"
        Me.Admin_Footer.Size = New System.Drawing.Size(1370, 47)
        Me.Admin_Footer.TabIndex = 54
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(568, 20)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(224, 18)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Developed By Loyola Web Team"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.Highlight
        Me.Label7.Location = New System.Drawing.Point(676, 50)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(143, 29)
        Me.Label7.TabIndex = 56
        Me.Label7.Text = "Information"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(562, 50)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(117, 29)
        Me.Label8.TabIndex = 55
        Me.Label8.Text = "Customer"
        '
        'CustomerInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 696)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Admin_Footer)
        Me.Controls.Add(Me.Filter_ComboBox)
        Me.Controls.Add(Me.Clear_btn)
        Me.Controls.Add(Me.Refresh_btn)
        Me.Controls.Add(Me.Delete_btn)
        Me.Controls.Add(Me.Update_btn)
        Me.Controls.Add(Me.Add_btn)
        Me.Controls.Add(Me.CustomerDataGridView)
        Me.Controls.Add(Me.sea_btn)
        Me.Controls.Add(Me.Search_txt)
        Me.Controls.Add(Me.address_txtbx)
        Me.Controls.Add(Me.address_lbl)
        Me.Controls.Add(Me.contact_txtbx)
        Me.Controls.Add(Me.contact_lbl)
        Me.Controls.Add(Me.email_txtbx)
        Me.Controls.Add(Me.email_lbl)
        Me.Controls.Add(Me.Name_txtbx)
        Me.Controls.Add(Me.Name_lbl)
        Me.Controls.Add(Me.ID_txtbx)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.ID_lbl)
        Me.Name = "CustomerInfo"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Easy Day Billing System | Customer Infomation"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.CustomerDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Admin_Footer.ResumeLayout(False)
        Me.Admin_Footer.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Search_txt As TextBox
    Friend WithEvents address_txtbx As TextBox
    Friend WithEvents address_lbl As Label
    Friend WithEvents contact_txtbx As TextBox
    Friend WithEvents contact_lbl As Label
    Friend WithEvents email_txtbx As TextBox
    Friend WithEvents email_lbl As Label
    Friend WithEvents Name_txtbx As TextBox
    Friend WithEvents Name_lbl As Label
    Friend WithEvents ID_txtbx As TextBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents ID_lbl As Label
    Friend WithEvents sea_btn As Button
    Friend WithEvents CustomerDataGridView As DataGridView
    Friend WithEvents Add_btn As Button
    Friend WithEvents Update_btn As Button
    Friend WithEvents Delete_btn As Button
    Friend WithEvents Refresh_btn As Button
    Friend WithEvents Clear_btn As Button
    Friend WithEvents Filter_ComboBox As ComboBox
    Friend WithEvents Admin_Footer As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
End Class
