﻿Imports System.Data
Imports System.Data.OleDb

Public Class CustomerInfo
    Private Sub CustomerInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim con As New OleDbConnection
        Dim cmd As OleDbDataAdapter
        Dim dset As New DataSet
        con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
        con.Open()
        cmd = New OleDbDataAdapter("Select * from customer ", con)
        cmd.Fill(dset, "customer")
        If (dset.Tables("customer").Rows.Count) > 0 Then
            CustomerDataGridView.DataSource = dset.Tables("customer").DefaultView
        End If
    End Sub

    Private Sub Refresh_btn_Click(sender As Object, e As EventArgs) Handles Refresh_btn.Click
        Dim con As New OleDbConnection
        Dim cmd As OleDbDataAdapter
        Dim dset As New DataSet
        con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
        con.Open()
        cmd = New OleDbDataAdapter("Select * from customer ", con)
        cmd.Fill(dset, "customer")
        If (dset.Tables("customer").Rows.Count) > 0 Then
            CustomerDataGridView.DataSource = dset.Tables("customer").DefaultView
        End If
    End Sub

    Private Sub Clear_btn_Click(sender As Object, e As EventArgs) Handles Clear_btn.Click
        Name_txtbx.Text = ""
        email_txtbx.Text = ""
        contact_txtbx.Text = ""
        address_txtbx.Text = ""
        Search_txt.Text = ""
        ID_txtbx.Text = ""
    End Sub

    Private Sub CustomerDataGridView_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles CustomerDataGridView.CellClick
        Dim index As Integer
        index = e.RowIndex
        Dim selectedrow As DataGridViewRow
        selectedrow = CustomerDataGridView.Rows(index)
        ID_txtbx.Text = selectedrow.Cells(0).Value.ToString()
        Name_txtbx.Text = selectedrow.Cells(1).Value.ToString()
        email_txtbx.Text = selectedrow.Cells(2).Value.ToString()
        contact_txtbx.Text = selectedrow.Cells(3).Value.ToString()
        address_txtbx.Text = selectedrow.Cells(4).Value.ToString()

    End Sub

    Private Sub sea_btn_Click(sender As Object, e As EventArgs) Handles sea_btn.Click
        If Search_txt.Text = "" Then
            MsgBox("Please Enter the Title in the search Box")
            Search_txt.Focus()
        ElseIf Filter_ComboBox.Text = "" Then
            MsgBox("Please choose the Filter Method in the Combobox")
            Filter_ComboBox.Focus()
        Else
            Dim con As New OleDbConnection
            Dim cmd As OleDbDataAdapter
            Dim dset As New DataSet
            con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
            con.Open()
            cmd = New OleDbDataAdapter("Select * from customer where " & Filter_ComboBox.Text & "='" & Search_txt.Text & "' ", con)
            cmd.Fill(dset, "customer")
            If (dset.Tables("customer").Rows.Count) > 0 Then
                CustomerDataGridView.DataSource = dset.Tables("customer").DefaultView
            End If
        End If
    End Sub

    Private Sub Add_btn_Click(sender As Object, e As EventArgs) Handles Add_btn.Click
        If Name_txtbx.Text = "" Then
            MsgBox("please Enter the Customer name")
            Name_txtbx.Focus()
        ElseIf email_txtbx.Text = "" Then
            MsgBox("Please Enter the Email")
            email_txtbx.Focus()
        ElseIf contact_txtbx.Text = "" Then
            MsgBox("please Enter the Contact Number")
            contact_txtbx.Focus()
        ElseIf address_txtbx.Text = "" Then
            MsgBox("Please Enter the Address of the Customer")
            address_txtbx.Focus()
        Else
            Dim con As New OleDbConnection
            Dim updata As New OleDbCommand
            Dim name As String = Name_txtbx.Text
            Dim email As String = email_txtbx.Text
            Dim contact As Double = Double.Parse(contact_txtbx.Text)
            Dim address As String = address_txtbx.Text
            con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
            con.Open()
            updata.Connection = con
            updata.CommandText = "Insert into customer" & "(name,email,contact,address,added_date)" & "values('" & name & "','" & email & "','" & contact & "','" & address & "','" & DateTimePicker1.Value.Date & "')"
            updata.ExecuteNonQuery()
            MsgBox("Successfully Added")
        End If
    End Sub

    Private Sub Update_btn_Click(sender As Object, e As EventArgs) Handles Update_btn.Click
        If Name_txtbx.Text = "" Then
            MsgBox("please select the Customer to update")
        ElseIf email_txtbx.Text = "" Then
            MsgBox("please select the Customer to update")

        ElseIf contact_txtbx.Text = ""
            MsgBox("please select the Customer to update")

        ElseIf address_txtbx.Text = "" Then
            MsgBox("please select the Customer to update")

        Else
            Dim con As New OleDbConnection
            Dim updata As New OleDbCommand
            con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
            con.Open()
            updata.Connection = con
            updata.CommandText = "UPDATE customer SET name='" & Name_txtbx.Text & "',email='" & email_txtbx.Text & "',contact='" & contact_txtbx.Text & "',address='" & address_txtbx.Text & "'WHERE ID=" & ID_txtbx.Text & ""
            updata.ExecuteNonQuery()
            MsgBox("sucessfully Updated")
        End If
    End Sub

    Private Sub Delete_btn_Click(sender As Object, e As EventArgs) Handles Delete_btn.Click
        If Name_txtbx.Text = "" Then
            MsgBox("please select the Customer to Delete")
        ElseIf email_txtbx.Text = "" Then
            MsgBox("please select the Customer to Delete")

        ElseIf contact_txtbx.Text = "" Then
            MsgBox("please select the Customer to Delete")

        ElseIf address_txtbx.Text = "" Then
            MsgBox("please select the Customer to Delete")

        Else
            Dim con As New OleDbConnection
            Dim updata As New OleDbCommand
            con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
            con.Open()
            updata.Connection = con
            updata.CommandText = "Delete from customer where name = '" & Name_txtbx.Text & "'"
            updata.ExecuteNonQuery()
            MsgBox("sucessfully Deleted")
        End If
    End Sub
End Class