﻿Imports System.Data
Imports System.Data.OleDb

Public Class LOGIN
    Private Sub Clear_btn_Click(sender As Object, e As EventArgs) Handles Clear_btn.Click
        User_text.Text = ""
        pass_txt.Text = ""

    End Sub

    Private Sub Submit_btn_Click(sender As Object, e As EventArgs) Handles Submit_btn.Click
        If User_text.Text = "" Then
            MsgBox("Please Enter the Username")
            User_text.Focus()
        ElseIf pass_txt.Text = "" Then
            MsgBox("Please enter the password to Login")
            pass_txt.Focus()
        Else
            Dim con As New OleDbConnection
            Dim cmd As OleDbDataAdapter
            Dim dset As New DataSet
            Dim pwd, uname As String
            con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
            con.Open()
            cmd = New OleDbDataAdapter("Select * from Userdetails where username = " & "'" & User_text.Text & "'", con)
            cmd.Fill(dset, "Userdetails")
            If (dset.Tables("Userdetails").Rows.Count) > 0 Then
                uname = dset.Tables("Userdetails").Rows(0).Item("username")
                pwd = dset.Tables("Userdetails").Rows(0).Item("password")
                If (pass_txt.Text = pwd) Then
                    MsgBox("Welcome Boss")
                    Admin_Dashboard.Show()
                    Me.Hide()
                Else

                    MsgBox("Check the password you have entered")
                End If
            End If

        End If
    End Sub


End Class