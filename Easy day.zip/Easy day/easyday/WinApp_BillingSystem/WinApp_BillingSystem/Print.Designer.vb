﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Print
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.printGridView = New System.Windows.Forms.DataGridView()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.CusID = New System.Windows.Forms.Label()
        Me.cusname = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Sub_txt = New System.Windows.Forms.Label()
        Me.dis_txt = New System.Windows.Forms.Label()
        Me.GST_txt = New System.Windows.Forms.Label()
        Me.ToT_txt = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.EasyPrintDialog = New System.Windows.Forms.PrintDialog()
        Me.EasyPrintDocument = New System.Drawing.Printing.PrintDocument()
        Me.Printpro = New System.Windows.Forms.Button()
        CType(Me.printGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(232, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(90, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Bill Receipt"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(193, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(178, 17)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Easy Day Super Market"
        '
        'printGridView
        '
        Me.printGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.printGridView.Location = New System.Drawing.Point(12, 144)
        Me.printGridView.Name = "printGridView"
        Me.printGridView.Size = New System.Drawing.Size(530, 150)
        Me.printGridView.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(99, 106)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(101, 17)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Customer ID:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(313, 106)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(127, 17)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Customer Name:"
        '
        'CusID
        '
        Me.CusID.AutoSize = True
        Me.CusID.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CusID.Location = New System.Drawing.Point(201, 106)
        Me.CusID.Name = "CusID"
        Me.CusID.Size = New System.Drawing.Size(0, 17)
        Me.CusID.TabIndex = 7
        '
        'cusname
        '
        Me.cusname.AutoSize = True
        Me.cusname.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cusname.Location = New System.Drawing.Point(437, 106)
        Me.cusname.Name = "cusname"
        Me.cusname.Size = New System.Drawing.Size(0, 17)
        Me.cusname.TabIndex = 8
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(419, 315)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(84, 17)
        Me.Label14.TabIndex = 63
        Me.Label14.Text = "Grand Total"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(296, 315)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(59, 17)
        Me.Label13.TabIndex = 62
        Me.Label13.Text = "GST(%)"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(151, 315)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(85, 17)
        Me.Label12.TabIndex = 61
        Me.Label12.Text = "Discount(%)"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(12, 315)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(69, 17)
        Me.Label11.TabIndex = 60
        Me.Label11.Text = "Sub Total"
        '
        'Sub_txt
        '
        Me.Sub_txt.AutoSize = True
        Me.Sub_txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Sub_txt.Location = New System.Drawing.Point(12, 357)
        Me.Sub_txt.Name = "Sub_txt"
        Me.Sub_txt.Size = New System.Drawing.Size(0, 17)
        Me.Sub_txt.TabIndex = 64
        '
        'dis_txt
        '
        Me.dis_txt.AutoSize = True
        Me.dis_txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dis_txt.Location = New System.Drawing.Point(151, 357)
        Me.dis_txt.Name = "dis_txt"
        Me.dis_txt.Size = New System.Drawing.Size(0, 17)
        Me.dis_txt.TabIndex = 65
        '
        'GST_txt
        '
        Me.GST_txt.AutoSize = True
        Me.GST_txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GST_txt.Location = New System.Drawing.Point(296, 357)
        Me.GST_txt.Name = "GST_txt"
        Me.GST_txt.Size = New System.Drawing.Size(0, 17)
        Me.GST_txt.TabIndex = 66
        '
        'ToT_txt
        '
        Me.ToT_txt.AutoSize = True
        Me.ToT_txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToT_txt.Location = New System.Drawing.Point(419, 357)
        Me.ToT_txt.Name = "ToT_txt"
        Me.ToT_txt.Size = New System.Drawing.Size(0, 17)
        Me.ToT_txt.TabIndex = 67
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(185, 427)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(170, 17)
        Me.Label5.TabIndex = 68
        Me.Label5.Text = "Thank You  Visit Again....!"
        '
        'EasyPrintDialog
        '
        Me.EasyPrintDialog.UseEXDialog = True
        '
        'Printpro
        '
        Me.Printpro.Location = New System.Drawing.Point(467, 421)
        Me.Printpro.Name = "Printpro"
        Me.Printpro.Size = New System.Drawing.Size(75, 23)
        Me.Printpro.TabIndex = 69
        Me.Printpro.Text = "Print"
        Me.Printpro.UseVisualStyleBackColor = True
        '
        'Print
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(563, 456)
        Me.Controls.Add(Me.Printpro)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.ToT_txt)
        Me.Controls.Add(Me.GST_txt)
        Me.Controls.Add(Me.dis_txt)
        Me.Controls.Add(Me.Sub_txt)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.cusname)
        Me.Controls.Add(Me.CusID)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.printGridView)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Name = "Print"
        Me.Text = "Easy Day Billing System | Print"
        CType(Me.printGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents printGridView As DataGridView
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents CusID As Label
    Friend WithEvents cusname As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Sub_txt As Label
    Friend WithEvents dis_txt As Label
    Friend WithEvents GST_txt As Label
    Friend WithEvents ToT_txt As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents EasyPrintDialog As PrintDialog
    Friend WithEvents EasyPrintDocument As Printing.PrintDocument
    Friend WithEvents Printpro As Button
End Class
