﻿Public Class Print
    Private Sub Print_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        printGridView.DataSource = My.Forms.BilligSection.ProductGridview.DataSource
        CusID.Text = My.Forms.BilligSection.CusID_txt.Text
        cusname.Text = My.Forms.BilligSection.Name_txt.Text
        Sub_txt.Text = My.Forms.BilligSection.Subtotal_txt.Text
        dis_txt.Text = My.Forms.BilligSection.Discount_txt.Text
        GST_txt.Text = My.Forms.BilligSection.vat_txt.Text
        ToT_txt.Text = My.Forms.BilligSection.Grandtotal_txt.Text


    End Sub

    Private Sub Printpro_Click(sender As Object, e As EventArgs) Handles Printpro.Click
        EasyPrintDialog.Document = EasyPrintDocument
        EasyPrintDialog.PrinterSettings = EasyPrintDocument.PrinterSettings
        EasyPrintDialog.AllowCurrentPage = True
        EasyPrintDialog.AllowSelection = True
        EasyPrintDialog.AllowSomePages = True
        If EasyPrintDialog.ShowDialog = DialogResult.OK Then
            EasyPrintDocument.Print()
        End If
    End Sub
End Class