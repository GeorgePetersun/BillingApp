﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Products
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.name_txt = New System.Windows.Forms.TextBox()
        Me.des_txt = New System.Windows.Forms.TextBox()
        Me.rate_txt = New System.Windows.Forms.TextBox()
        Me.cat_ComboBox = New System.Windows.Forms.ComboBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.add_btn = New System.Windows.Forms.Button()
        Me.update_txt = New System.Windows.Forms.Button()
        Me.delete_btn = New System.Windows.Forms.Button()
        Me.refresh_btn = New System.Windows.Forms.Button()
        Me.Clear_btn = New System.Windows.Forms.Button()
        Me.Search_btn = New System.Windows.Forms.Button()
        Me.seach_txt = New System.Windows.Forms.TextBox()
        Me.productDataGridView = New System.Windows.Forms.DataGridView()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.id_txt = New System.Windows.Forms.TextBox()
        Me.Filter_ComboBox = New System.Windows.Forms.ComboBox()
        Me.Admin_Footer = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        CType(Me.productDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Admin_Footer.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(192, 273)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(79, 17)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Description"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(192, 225)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Category"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(192, 190)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(45, 17)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(192, 385)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(38, 17)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Rate"
        '
        'name_txt
        '
        Me.name_txt.Location = New System.Drawing.Point(272, 190)
        Me.name_txt.Name = "name_txt"
        Me.name_txt.Size = New System.Drawing.Size(237, 20)
        Me.name_txt.TabIndex = 6
        '
        'des_txt
        '
        Me.des_txt.Location = New System.Drawing.Point(272, 273)
        Me.des_txt.Multiline = True
        Me.des_txt.Name = "des_txt"
        Me.des_txt.Size = New System.Drawing.Size(237, 88)
        Me.des_txt.TabIndex = 7
        '
        'rate_txt
        '
        Me.rate_txt.Location = New System.Drawing.Point(272, 384)
        Me.rate_txt.Name = "rate_txt"
        Me.rate_txt.Size = New System.Drawing.Size(237, 20)
        Me.rate_txt.TabIndex = 8
        '
        'cat_ComboBox
        '
        Me.cat_ComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cat_ComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cat_ComboBox.FormattingEnabled = True
        Me.cat_ComboBox.Location = New System.Drawing.Point(272, 225)
        Me.cat_ComboBox.Name = "cat_ComboBox"
        Me.cat_ComboBox.Size = New System.Drawing.Size(237, 21)
        Me.cat_ComboBox.TabIndex = 10
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(272, 110)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(237, 20)
        Me.DateTimePicker1.TabIndex = 11
        Me.DateTimePicker1.Visible = False
        '
        'add_btn
        '
        Me.add_btn.Location = New System.Drawing.Point(272, 440)
        Me.add_btn.Name = "add_btn"
        Me.add_btn.Size = New System.Drawing.Size(75, 23)
        Me.add_btn.TabIndex = 12
        Me.add_btn.Text = "Add"
        Me.add_btn.UseVisualStyleBackColor = True
        '
        'update_txt
        '
        Me.update_txt.Location = New System.Drawing.Point(353, 440)
        Me.update_txt.Name = "update_txt"
        Me.update_txt.Size = New System.Drawing.Size(75, 23)
        Me.update_txt.TabIndex = 13
        Me.update_txt.Text = "Edit"
        Me.update_txt.UseVisualStyleBackColor = True
        '
        'delete_btn
        '
        Me.delete_btn.Location = New System.Drawing.Point(434, 440)
        Me.delete_btn.Name = "delete_btn"
        Me.delete_btn.Size = New System.Drawing.Size(75, 23)
        Me.delete_btn.TabIndex = 14
        Me.delete_btn.Text = "Delete"
        Me.delete_btn.UseVisualStyleBackColor = True
        '
        'refresh_btn
        '
        Me.refresh_btn.Location = New System.Drawing.Point(316, 479)
        Me.refresh_btn.Name = "refresh_btn"
        Me.refresh_btn.Size = New System.Drawing.Size(75, 23)
        Me.refresh_btn.TabIndex = 15
        Me.refresh_btn.Text = "Refresh"
        Me.refresh_btn.UseVisualStyleBackColor = True
        '
        'Clear_btn
        '
        Me.Clear_btn.Location = New System.Drawing.Point(397, 479)
        Me.Clear_btn.Name = "Clear_btn"
        Me.Clear_btn.Size = New System.Drawing.Size(75, 23)
        Me.Clear_btn.TabIndex = 16
        Me.Clear_btn.Text = "Clear"
        Me.Clear_btn.UseVisualStyleBackColor = True
        '
        'Search_btn
        '
        Me.Search_btn.Location = New System.Drawing.Point(918, 138)
        Me.Search_btn.Name = "Search_btn"
        Me.Search_btn.Size = New System.Drawing.Size(75, 23)
        Me.Search_btn.TabIndex = 17
        Me.Search_btn.Text = "Search"
        Me.Search_btn.UseVisualStyleBackColor = True
        '
        'seach_txt
        '
        Me.seach_txt.Location = New System.Drawing.Point(689, 141)
        Me.seach_txt.Name = "seach_txt"
        Me.seach_txt.Size = New System.Drawing.Size(223, 20)
        Me.seach_txt.TabIndex = 18
        '
        'productDataGridView
        '
        Me.productDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.productDataGridView.Location = New System.Drawing.Point(562, 190)
        Me.productDataGridView.Name = "productDataGridView"
        Me.productDataGridView.Size = New System.Drawing.Size(631, 312)
        Me.productDataGridView.TabIndex = 19
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(192, 145)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(21, 17)
        Me.Label6.TabIndex = 20
        Me.Label6.Text = "ID"
        '
        'id_txt
        '
        Me.id_txt.Location = New System.Drawing.Point(272, 144)
        Me.id_txt.Name = "id_txt"
        Me.id_txt.ReadOnly = True
        Me.id_txt.Size = New System.Drawing.Size(237, 20)
        Me.id_txt.TabIndex = 21
        '
        'Filter_ComboBox
        '
        Me.Filter_ComboBox.FormattingEnabled = True
        Me.Filter_ComboBox.Items.AddRange(New Object() {"name", "category"})
        Me.Filter_ComboBox.Location = New System.Drawing.Point(562, 141)
        Me.Filter_ComboBox.Name = "Filter_ComboBox"
        Me.Filter_ComboBox.Size = New System.Drawing.Size(121, 21)
        Me.Filter_ComboBox.TabIndex = 22
        '
        'Admin_Footer
        '
        Me.Admin_Footer.BackColor = System.Drawing.SystemColors.Highlight
        Me.Admin_Footer.Controls.Add(Me.Label5)
        Me.Admin_Footer.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Admin_Footer.Location = New System.Drawing.Point(0, 649)
        Me.Admin_Footer.Name = "Admin_Footer"
        Me.Admin_Footer.Size = New System.Drawing.Size(1370, 47)
        Me.Admin_Footer.TabIndex = 23
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.Highlight
        Me.Label7.Location = New System.Drawing.Point(665, 50)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(143, 29)
        Me.Label7.TabIndex = 25
        Me.Label7.Text = "Information"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(568, 20)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(224, 18)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Developed By Loyola Web Team"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(563, 50)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(96, 29)
        Me.Label8.TabIndex = 24
        Me.Label8.Text = "Product"
        '
        'Products
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 696)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Admin_Footer)
        Me.Controls.Add(Me.Filter_ComboBox)
        Me.Controls.Add(Me.id_txt)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.productDataGridView)
        Me.Controls.Add(Me.seach_txt)
        Me.Controls.Add(Me.Search_btn)
        Me.Controls.Add(Me.Clear_btn)
        Me.Controls.Add(Me.refresh_btn)
        Me.Controls.Add(Me.delete_btn)
        Me.Controls.Add(Me.update_txt)
        Me.Controls.Add(Me.add_btn)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.cat_ComboBox)
        Me.Controls.Add(Me.rate_txt)
        Me.Controls.Add(Me.des_txt)
        Me.Controls.Add(Me.name_txt)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Products"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Easy Day Billing System | Products"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.productDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Admin_Footer.ResumeLayout(False)
        Me.Admin_Footer.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents name_txt As TextBox
    Friend WithEvents des_txt As TextBox
    Friend WithEvents rate_txt As TextBox
    Friend WithEvents cat_ComboBox As ComboBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents add_btn As Button
    Friend WithEvents update_txt As Button
    Friend WithEvents delete_btn As Button
    Friend WithEvents refresh_btn As Button
    Friend WithEvents Clear_btn As Button
    Friend WithEvents Search_btn As Button
    Friend WithEvents seach_txt As TextBox
    Friend WithEvents productDataGridView As DataGridView
    Friend WithEvents Label6 As Label
    Friend WithEvents id_txt As TextBox
    Friend WithEvents Filter_ComboBox As ComboBox
    Friend WithEvents Admin_Footer As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
End Class
