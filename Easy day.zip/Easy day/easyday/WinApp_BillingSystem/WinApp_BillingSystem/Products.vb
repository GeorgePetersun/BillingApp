﻿Imports System.Data
Imports System.Data.OleDb

Public Class Products

    Private Sub Products_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        load()
        Dim con As New OleDbConnection
        Dim cmd As New OleDbCommand
        con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
        con.Open()
        cmd.Connection = con
        cmd.CommandText = "select title from category"
        Dim dr As OleDbDataReader = cmd.ExecuteReader
        While dr.Read
            cat_ComboBox.Items.Add(dr.Item(0))
        End While
    End Sub

    Private Sub add_btn_Click(sender As Object, e As EventArgs) Handles add_btn.Click

        If name_txt.Text = "" Then
            MsgBox("please Enter the Product name")
            name_txt.Focus()
        ElseIf cat_ComboBox.Text = "" Then
            MsgBox("Please Choose the category")
            cat_ComboBox.Focus()
        ElseIf des_txt.Text = ""
            MsgBox("please enter the description")
            des_txt.Focus()
        ElseIf rate_txt.Text = "" Then
            MsgBox("Please enter the price of the product")
            rate_txt.Focus()

        Else
            Dim con As New OleDbConnection
            Dim updata As New OleDbCommand
            Dim name As String = name_txt.Text
            Dim cat As String = cat_ComboBox.Text
            Dim des As String = des_txt.Text
            Dim rate As Double = Double.Parse(rate_txt.Text)
            con = New OleDbConnection("PROVIDER=" & "Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
            con.Open()
            updata.Connection = con
            updata.CommandText = "Insert into products" & "(name,category,description,rate,added_date)" & "values('" & name & "','" & cat & "','" & des & "','" & rate & "','" & DateTimePicker1.Value.Date & "')"
            updata.ExecuteNonQuery()
            MsgBox("Succesfully Added")
            load()
        End If
    End Sub

    Private Sub refresh_btn_Click(sender As Object, e As EventArgs) Handles refresh_btn.Click
        Dim con As New OleDbConnection
        Dim cmd As OleDbDataAdapter
        Dim dset As New DataSet
        con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
        con.Open()
        cmd = New OleDbDataAdapter("Select * from products ", con)
        cmd.Fill(dset, "products")
        If (dset.Tables("products").Rows.Count) > 0 Then
            productDataGridView.DataSource = dset.Tables("products").DefaultView
        End If
    End Sub

    Private Sub Clear_btn_Click(sender As Object, e As EventArgs) Handles Clear_btn.Click
        name_txt.Text = ""
        cat_ComboBox.Text = ""
        des_txt.Text = ""
        rate_txt.Text = ""
        seach_txt.Text = ""

    End Sub

    Private Sub Search_btn_Click(sender As Object, e As EventArgs) Handles Search_btn.Click
        If seach_txt.Text = "" Then
            MsgBox("Please Enter the Title in the search Box")
            seach_txt.Focus()
        ElseIf Filter_ComboBox.Text = "" Then
            MsgBox("please Choose the Filter Method in the Combobox")
            Filter_ComboBox.Focus()
        Else
            Dim con As New OleDbConnection
            Dim cmd As OleDbDataAdapter
            Dim dset As New DataSet
            con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
            con.Open()
            cmd = New OleDbDataAdapter("Select * from products where " & Filter_ComboBox.Text & "='" & seach_txt.Text & "' ", con)
            cmd.Fill(dset, "products")
            If (dset.Tables("products").Rows.Count) > 0 Then
                productDataGridView.DataSource = dset.Tables("products").DefaultView
            End If
        End If
    End Sub

    Private Sub delete_btn_Click(sender As Object, e As EventArgs) Handles delete_btn.Click

        If name_txt.Text = "" Then
            MsgBox("please select the Product to Delete")
        ElseIf cat_ComboBox.Text = "" Then
            MsgBox("please select the Product to Delete")

        ElseIf des_txt.Text = ""
            MsgBox("please select the Product to Delete")

        ElseIf rate_txt.Text = "" Then
            MsgBox("please select the Product to Delete")

        Else
            Dim con As New OleDbConnection
            Dim updata As New OleDbCommand
            con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
            con.Open()
            updata.Connection = con
            updata.CommandText = "Delete from products where name = '" & name_txt.Text & "'"
            updata.ExecuteNonQuery()
            MsgBox("sucessfully Deleted")
            load()
        End If

    End Sub

    Private Sub productDataGridView_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles productDataGridView.CellClick
        Dim index As Integer
        index = e.RowIndex
        Dim selectedrow As DataGridViewRow
        selectedrow = productDataGridView.Rows(index)
        id_txt.Text = selectedrow.Cells(0).Value.ToString()
        name_txt.Text = selectedrow.Cells(1).Value.ToString()
        cat_ComboBox.Text = selectedrow.Cells(2).Value.ToString()
        des_txt.Text = selectedrow.Cells(3).Value.ToString()
        rate_txt.Text = selectedrow.Cells(4).Value.ToString()


    End Sub

    Private Sub update_txt_Click(sender As Object, e As EventArgs) Handles update_txt.Click

        If name_txt.Text = "" Then
            MsgBox("please select the Product to update")
        ElseIf cat_ComboBox.Text = "" Then
            MsgBox("please select the Product to update")

        ElseIf des_txt.Text = ""
            MsgBox("please select the Product to update")

        ElseIf rate_txt.Text = "" Then
            MsgBox("please select the Product to update")



        Else
            Dim con As New OleDbConnection
            Dim updata As New OleDbCommand
            con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
            con.Open()
            updata.Connection = con
            updata.CommandText = "UPDATE products SET name='" & name_txt.Text & "',category='" & cat_ComboBox.Text & "',description='" & des_txt.Text & "',rate='" & rate_txt.Text & "'WHERE ID=" & id_txt.Text & ""
            updata.ExecuteNonQuery()
            MsgBox("sucessfully Updated")
            load()
        End If
    End Sub
    Public Function load()
        Dim con As New OleDbConnection
        Dim cmd As OleDbDataAdapter
        Dim dset As New DataSet
        con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
        con.Open()
        cmd = New OleDbDataAdapter("Select * from products ", con)
        cmd.Fill(dset, "products")
        If (dset.Tables("products").Rows.Count) > 0 Then
            productDataGridView.DataSource = dset.Tables("products").DefaultView
        End If
        Return 0
    End Function


End Class