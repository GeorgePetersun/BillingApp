﻿Imports System.Data
Imports System.Data.OleDb
Public Class SalesReport
    Private Sub SalesReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim con As New OleDbConnection
        Dim cmd As OleDbDataAdapter
        Dim dset As New DataSet
        con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
        con.Open()
        cmd = New OleDbDataAdapter("Select * from salesreport ", con)
        cmd.Fill(dset, "salesreport")
        If (dset.Tables("salesreport").Rows.Count) > 0 Then
            SalesGridView.DataSource = dset.Tables("salesreport").DefaultView
        End If
    End Sub
End Class