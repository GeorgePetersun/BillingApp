﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class category
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Title_txt = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.des_txt = New System.Windows.Forms.TextBox()
        Me.Add_txt = New System.Windows.Forms.Button()
        Me.Update_txt = New System.Windows.Forms.Button()
        Me.Delete_txt = New System.Windows.Forms.Button()
        Me.Clear_txt = New System.Windows.Forms.Button()
        Me.display_txtbx = New System.Windows.Forms.TextBox()
        Me.Search_txt = New System.Windows.Forms.Button()
        Me.catgoryGridView = New System.Windows.Forms.DataGridView()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.View_txt = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.id_txt = New System.Windows.Forms.TextBox()
        Me.Admin_Footer = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        CType(Me.catgoryGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Admin_Footer.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(235, 201)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Title "
        '
        'Title_txt
        '
        Me.Title_txt.Location = New System.Drawing.Point(331, 200)
        Me.Title_txt.Name = "Title_txt"
        Me.Title_txt.Size = New System.Drawing.Size(237, 20)
        Me.Title_txt.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(235, 239)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Description"
        '
        'des_txt
        '
        Me.des_txt.Location = New System.Drawing.Point(331, 238)
        Me.des_txt.Multiline = True
        Me.des_txt.Name = "des_txt"
        Me.des_txt.Size = New System.Drawing.Size(237, 136)
        Me.des_txt.TabIndex = 3
        '
        'Add_txt
        '
        Me.Add_txt.Location = New System.Drawing.Point(331, 380)
        Me.Add_txt.Name = "Add_txt"
        Me.Add_txt.Size = New System.Drawing.Size(75, 23)
        Me.Add_txt.TabIndex = 4
        Me.Add_txt.Text = "Add"
        Me.Add_txt.UseVisualStyleBackColor = True
        '
        'Update_txt
        '
        Me.Update_txt.Location = New System.Drawing.Point(412, 380)
        Me.Update_txt.Name = "Update_txt"
        Me.Update_txt.Size = New System.Drawing.Size(75, 23)
        Me.Update_txt.TabIndex = 5
        Me.Update_txt.Text = "Edit"
        Me.Update_txt.UseVisualStyleBackColor = True
        '
        'Delete_txt
        '
        Me.Delete_txt.Location = New System.Drawing.Point(493, 380)
        Me.Delete_txt.Name = "Delete_txt"
        Me.Delete_txt.Size = New System.Drawing.Size(75, 23)
        Me.Delete_txt.TabIndex = 6
        Me.Delete_txt.Text = "Delete"
        Me.Delete_txt.UseVisualStyleBackColor = True
        '
        'Clear_txt
        '
        Me.Clear_txt.Location = New System.Drawing.Point(455, 411)
        Me.Clear_txt.Name = "Clear_txt"
        Me.Clear_txt.Size = New System.Drawing.Size(75, 23)
        Me.Clear_txt.TabIndex = 8
        Me.Clear_txt.Text = "Clear"
        Me.Clear_txt.UseVisualStyleBackColor = True
        '
        'display_txtbx
        '
        Me.display_txtbx.Location = New System.Drawing.Point(682, 152)
        Me.display_txtbx.Name = "display_txtbx"
        Me.display_txtbx.Size = New System.Drawing.Size(205, 20)
        Me.display_txtbx.TabIndex = 9
        '
        'Search_txt
        '
        Me.Search_txt.Location = New System.Drawing.Point(893, 150)
        Me.Search_txt.Name = "Search_txt"
        Me.Search_txt.Size = New System.Drawing.Size(75, 23)
        Me.Search_txt.TabIndex = 10
        Me.Search_txt.Text = "Search"
        Me.Search_txt.UseVisualStyleBackColor = True
        '
        'catgoryGridView
        '
        Me.catgoryGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.catgoryGridView.Location = New System.Drawing.Point(682, 200)
        Me.catgoryGridView.Name = "catgoryGridView"
        Me.catgoryGridView.Size = New System.Drawing.Size(440, 234)
        Me.catgoryGridView.TabIndex = 11
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(331, 110)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(237, 20)
        Me.DateTimePicker1.TabIndex = 13
        Me.DateTimePicker1.Visible = False
        '
        'View_txt
        '
        Me.View_txt.Location = New System.Drawing.Point(374, 411)
        Me.View_txt.Name = "View_txt"
        Me.View_txt.Size = New System.Drawing.Size(75, 23)
        Me.View_txt.TabIndex = 7
        Me.View_txt.Text = "Refresh"
        Me.View_txt.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(235, 159)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(21, 17)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "ID"
        '
        'id_txt
        '
        Me.id_txt.Location = New System.Drawing.Point(331, 152)
        Me.id_txt.Name = "id_txt"
        Me.id_txt.ReadOnly = True
        Me.id_txt.Size = New System.Drawing.Size(237, 20)
        Me.id_txt.TabIndex = 15
        '
        'Admin_Footer
        '
        Me.Admin_Footer.BackColor = System.Drawing.SystemColors.Highlight
        Me.Admin_Footer.Controls.Add(Me.Label4)
        Me.Admin_Footer.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Admin_Footer.Location = New System.Drawing.Point(0, 649)
        Me.Admin_Footer.Name = "Admin_Footer"
        Me.Admin_Footer.Size = New System.Drawing.Size(1370, 47)
        Me.Admin_Footer.TabIndex = 16
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(558, 20)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(224, 18)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Developed By Loyola Web Team"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.Highlight
        Me.Label7.Location = New System.Drawing.Point(662, 52)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(143, 29)
        Me.Label7.TabIndex = 27
        Me.Label7.Text = "Information"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(560, 52)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(110, 29)
        Me.Label8.TabIndex = 26
        Me.Label8.Text = "Category"
        '
        'category
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 696)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Admin_Footer)
        Me.Controls.Add(Me.id_txt)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.catgoryGridView)
        Me.Controls.Add(Me.Search_txt)
        Me.Controls.Add(Me.display_txtbx)
        Me.Controls.Add(Me.Clear_txt)
        Me.Controls.Add(Me.View_txt)
        Me.Controls.Add(Me.Delete_txt)
        Me.Controls.Add(Me.Update_txt)
        Me.Controls.Add(Me.Add_txt)
        Me.Controls.Add(Me.des_txt)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Title_txt)
        Me.Controls.Add(Me.Label1)
        Me.Name = "category"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Easy Day Billing System | Category"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.catgoryGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Admin_Footer.ResumeLayout(False)
        Me.Admin_Footer.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Title_txt As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents des_txt As TextBox
    Friend WithEvents Add_txt As Button
    Friend WithEvents Update_txt As Button
    Friend WithEvents Delete_txt As Button
    Friend WithEvents Clear_txt As Button
    Friend WithEvents display_txtbx As TextBox
    Friend WithEvents Search_txt As Button
    Friend WithEvents catgoryGridView As DataGridView
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents View_txt As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents id_txt As TextBox
    Friend WithEvents Admin_Footer As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
End Class
