﻿Imports System.Data
Imports System.Data.OleDb

Public Class category
    Private Sub Clear_txt_Click(sender As Object, e As EventArgs) Handles Clear_txt.Click
        Title_txt.Text = ""
        des_txt.Text = ""
        display_txtbx.Text = ""
        id_txt.Text = ""

    End Sub

    Private Sub Add_txt_Click(sender As Object, e As EventArgs) Handles Add_txt.Click
        If Title_txt.Text = "" Then
            MsgBox("please Enter the Category Title")
            Title_txt.Focus()
        ElseIf des_txt.Text = "" Then
            MsgBox("Please Enter the description for the category")
        Else
            Dim con As New OleDbConnection
            Dim updata As New OleDbCommand
            con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
            con.Open()
            updata.Connection = con
            updata.CommandText = "insert into category" & "(title,description,added_date)" & "values('" & Title_txt.Text & "','" & des_txt.Text & "','" & DateTimePicker1.Value.Date & "')"
            updata.ExecuteNonQuery()
            MsgBox("Successfully Added")
        End If
    End Sub

    Private Sub category_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim con As New OleDbConnection
        Dim cmd As OleDbDataAdapter
        Dim dset As New DataSet
        con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
        con.Open()
        cmd = New OleDbDataAdapter("Select * from category ", con)
        cmd.Fill(dset, "category")
        If (dset.Tables("category").Rows.Count) > 0 Then
            catgoryGridView.DataSource = dset.Tables("category").DefaultView
        End If
    End Sub

    Private Sub View_txt_Click(sender As Object, e As EventArgs) Handles View_txt.Click
        Dim con As New OleDbConnection
        Dim cmd As OleDbDataAdapter
        Dim dset As New DataSet
        con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
        con.Open()
        cmd = New OleDbDataAdapter("Select * from category ", con)
        cmd.Fill(dset, "category")
        If (dset.Tables("category").Rows.Count) > 0 Then
            catgoryGridView.DataSource = dset.Tables("category").DefaultView
        End If
    End Sub

    Private Sub Search_txt_Click(sender As Object, e As EventArgs) Handles Search_txt.Click

        If display_txtbx.Text = "" Then
            MsgBox("Please Enter the value in the search Box")
            display_txtbx.Focus()

        Else
            Dim con As New OleDbConnection
            Dim cmd As OleDbDataAdapter
            Dim dset As New DataSet
            con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
            con.Open()
            cmd = New OleDbDataAdapter("Select * from category where title = '" & display_txtbx.Text & "' ", con)
            cmd.Fill(dset, "category")
            If (dset.Tables("category").Rows.Count) > 0 Then
                catgoryGridView.DataSource = dset.Tables("category").DefaultView
            End If
        End If
    End Sub

    Private Sub Delete_txt_Click(sender As Object, e As EventArgs) Handles Delete_txt.Click
        If Title_txt.Text = "" Then
            MsgBox("Please select the Category that you want to delete")
        ElseIf des_txt.Text = "" Then
            MsgBox("Please select the Category that you want to delete")
        Else
            Dim con As New OleDbConnection
            Dim updata As New OleDbCommand
            con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
            con.Open()
            updata.Connection = con
            updata.CommandText = "Delete from category where title = '" & Title_txt.Text & "'"
            updata.ExecuteNonQuery()
            MsgBox("Successfully deleted ")
        End If
    End Sub

    Private Sub Update_txt_Click(sender As Object, e As EventArgs) Handles Update_txt.Click
        If Title_txt.Text = "" Then
            MsgBox("Please select the Category that you want to update")
        ElseIf des_txt.Text = "" Then
            MsgBox("Please select the Category that you want to delete")
        Else
            Dim con As New OleDbConnection
            Dim updata As New OleDbCommand
            con = New OleDbConnection("PROVIDER=Microsoft.Jet.OleDb.4.0;" & "DATA SOURCE=" & "D:\easyday_db\easyday_db.mdb;")
            con.Open()
            updata.Connection = con
            updata.CommandText = "UPDATE category SET title='" & Title_txt.Text & "',description='" & des_txt.Text & "'WHERE ID=" & id_txt.Text & ""
            updata.ExecuteNonQuery()
            MsgBox("Successfully Updated ")
        End If
    End Sub

    Private Sub catgoryGridView_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles catgoryGridView.CellClick
        Dim index As Integer
        index = e.RowIndex
        Dim selectedrow As DataGridViewRow
        selectedrow = catgoryGridView.Rows(index)
        id_txt.Text = selectedrow.Cells(0).Value.ToString()
        Title_txt.Text = selectedrow.Cells(1).Value.ToString()
        des_txt.Text = selectedrow.Cells(2).Value.ToString()

    End Sub
End Class